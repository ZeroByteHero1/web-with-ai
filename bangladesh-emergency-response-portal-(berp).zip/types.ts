
export enum EmergencyType {
  MEDICAL = 'Medical',
  POLICE = 'Police',
  FIRE = 'Fire',
  ACCIDENT = 'Accident',
  CRIME = 'Crime'
}

export enum ReportStatus {
  PENDING = 'Pending',
  DISPATCHED = 'Dispatched',
  RESOLVED = 'Resolved',
  CANCELLED = 'Cancelled'
}

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface EmergencyReport {
  id: string;
  type: EmergencyType;
  description: string;
  location: Coordinates;
  address: string;
  timestamp: Date;
  status: ReportStatus;
  reporterName: string;
  reporterPhone: string;
  mediaUrl?: string;
  aiTriage?: string;
}

export interface Facility {
  id: string;
  name: string;
  type: 'Hospital' | 'Police Station';
  location: Coordinates;
  phone: string;
  distance?: number;
}

export interface Ambulance {
  id: string;
  licensePlate: string;
  location: Coordinates;
  isAvailable: boolean;
  driverName: string;
  phone: string;
}
