
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { EmergencyMap } from './components/EmergencyMap';
import { EmergencyForm } from './components/EmergencyForm';
import { AdminPanel } from './components/AdminPanel';
import { SafetyGame } from './components/SafetyGame';
import { EmergencyType, ReportStatus, EmergencyReport, Facility, Coordinates } from './types';
import { Phone, MapPin, Truck, ShieldAlert, ChevronRight, Activity } from 'lucide-react';

// Mock Data
const MOCK_FACILITIES: Facility[] = [
  { id: '1', name: 'Dhaka Medical College', type: 'Hospital', location: { lat: 23.7259, lng: 90.3970 }, phone: '02-55165001' },
  { id: '2', name: 'United Hospital Ltd', type: 'Hospital', location: { lat: 23.8055, lng: 90.4172 }, phone: '10666' },
  { id: '3', name: 'Ramna Police Station', type: 'Police Station', location: { lat: 23.7431, lng: 90.3986 }, phone: '02-48312061' },
  { id: '4', name: 'Gulshan Police Station', type: 'Police Station', location: { lat: 23.7847, lng: 90.4158 }, phone: '02-9856513' },
];

const INITIAL_REPORTS: EmergencyReport[] = [
  { 
    id: 'R1', 
    type: EmergencyType.MEDICAL, 
    description: 'Breathing difficulty reported in Banani Area.', 
    location: { lat: 23.7940, lng: 90.4043 }, 
    address: 'Banani Road 11', 
    timestamp: new Date(), 
    status: ReportStatus.DISPATCHED,
    reporterName: 'Karim Ullah',
    reporterPhone: '01712345678'
  }
];

const App: React.FC = () => {
  const [activePage, setActivePage] = useState('home');
  const [userLocation, setUserLocation] = useState<Coordinates | null>(null);
  const [reports, setReports] = useState<EmergencyReport[]>(INITIAL_REPORTS);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => setUserLocation({ lat: 23.8103, lng: 90.4125 }) // Default to Dhaka
      );
    }
  }, []);

  const handleReportSubmit = (report: EmergencyReport) => {
    setReports([report, ...reports]);
  };

  const handleUpdateStatus = (id: string, status: ReportStatus) => {
    setReports(reports.map(r => r.id === id ? { ...r, status } : r));
  };

  const renderPage = () => {
    switch (activePage) {
      case 'map':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="text-3xl font-extrabold text-gray-900 mb-2">Emergency Facilities Locator</h1>
            <p className="text-gray-600 mb-8">Real-time GPS tracking of nearest hospitals and police stations across Bangladesh.</p>
            <EmergencyMap 
              userLocation={userLocation || { lat: 23.8103, lng: 90.4125 }} 
              facilities={MOCK_FACILITIES} 
            />
          </div>
        );
      case 'admin':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="text-3xl font-extrabold text-gray-900 mb-2">Admin Command Center</h1>
            <p className="text-gray-600 mb-8">Secure portal for emergency dispatchers and monitoring officials.</p>
            <AdminPanel reports={reports} onUpdateStatus={handleUpdateStatus} />
          </div>
        );
      case 'game':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <SafetyGame />
          </div>
        );
      default:
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-24">
              <div>
                <div className="inline-flex items-center px-4 py-2 rounded-full bg-red-50 text-red-600 text-sm font-bold mb-6 border border-red-100">
                  <Activity className="w-4 h-4 mr-2" />
                  Live Digital Dispatching Active
                </div>
                <h1 className="text-5xl sm:text-6xl font-black text-gray-900 leading-tight mb-6">
                  One Click <span className="text-red-600">Response</span> for Every Bangladeshi.
                </h1>
                <p className="text-lg text-gray-600 mb-8 max-w-lg leading-relaxed">
                  The National Emergency Response Portal integrates hospitals, police, and fire services into a single AI-powered digital infrastructure.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button 
                    onClick={() => setActivePage('map')}
                    className="flex-1 flex items-center justify-center px-8 py-4 bg-gray-900 text-white rounded-2xl font-bold hover:bg-gray-800 shadow-xl transition active:scale-95"
                  >
                    <MapPin className="w-5 h-5 mr-2" />
                    FIND NEAREST HELP
                  </button>
                  <button 
                    onClick={() => {
                      const el = document.getElementById('report-section');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="flex-1 flex items-center justify-center px-8 py-4 bg-white border-2 border-red-600 text-red-600 rounded-2xl font-bold hover:bg-red-50 transition active:scale-95"
                  >
                    <ShieldAlert className="w-5 h-5 mr-2" />
                    REPORT EMERGENCY
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="absolute -inset-4 bg-red-100 rounded-[3rem] opacity-30 blur-2xl"></div>
                <img 
                  src="https://images.unsplash.com/photo-1587019158091-1a103c5dd17f?auto=format&fit=crop&q=80&w=800" 
                  alt="Emergency Response" 
                  className="relative rounded-[2.5rem] shadow-2xl border-4 border-white transform hover:-rotate-1 transition duration-500"
                />
                <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-3xl shadow-xl border border-gray-100 max-w-xs animate-bounce-slow">
                  <div className="flex items-center mb-3">
                    <div className="bg-green-100 p-2 rounded-lg mr-3">
                      <Truck className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-gray-400 uppercase tracking-widest">Active Dispatch</div>
                      <div className="text-sm font-bold">Ambulance #420</div>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 font-medium">ETA: 4 Minutes to Gulshan-2</div>
                </div>
              </div>
            </div>

            <div id="report-section" className="scroll-mt-24">
              <EmergencyForm onSubmit={handleReportSubmit} userLocation={userLocation} />
            </div>

            <div className="mt-24">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold">Emergency Hotlines</h2>
                <p className="text-gray-500">Available 24/7 throughout Bangladesh</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'National Helpline', number: '999', icon: ShieldAlert, color: 'bg-red-600' },
                  { label: 'Health Hotline', number: '16263', icon: Activity, color: 'bg-green-600' },
                  { label: 'Women/Child', number: '109', icon: ShieldAlert, color: 'bg-purple-600' },
                  { label: 'Disaster Info', number: '1090', icon: ShieldAlert, color: 'bg-orange-600' },
                ].map((item, i) => (
                  <a 
                    key={i}
                    href={`tel:${item.number}`}
                    className="group bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all hover:-translate-y-1"
                  >
                    <div className={`${item.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4 text-white shadow-lg`}>
                      <item.icon className="w-6 h-6" />
                    </div>
                    <div className="text-xs font-bold text-gray-400 uppercase mb-1">{item.label}</div>
                    <div className="text-3xl font-black text-gray-900 flex items-center justify-between">
                      {item.number}
                      <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-red-500 transition-colors" />
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar onNavigate={setActivePage} activePage={activePage} />
      <main className="flex-grow">
        {renderPage()}
      </main>
      <footer className="bg-gray-900 text-white py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <div className="flex items-center mb-4">
                <ShieldAlert className="h-8 w-8 text-red-500 mr-2" />
                <span className="text-2xl font-bold tracking-tight">BERP</span>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Bangladesh Emergency Response Portal is an initiative to modernize our national safety infrastructure through digital integration and AI triage.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-gray-200">System Links</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><button onClick={() => setActivePage('home')}>Emergency Home</button></li>
                <li><button onClick={() => setActivePage('map')}>Hospital Directory</button></li>
                <li><button onClick={() => setActivePage('admin')}>Officer Login</button></li>
                <li><button onClick={() => setActivePage('game')}>Drill Training</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-gray-200">Legal</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
                <li>Digital Security Act Compliance</li>
                <li>Abuse Reporting</li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-800 text-center text-sm text-gray-500">
            © {new Date().getFullYear()} Government of Bangladesh. All Rights Reserved. Digital Bangladesh 2041.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
