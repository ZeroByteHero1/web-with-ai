
import React, { useState, useEffect } from 'react';
import { Shield, Timer, Award, RotateCcw, Flame, Droplets, HeartPulse } from 'lucide-react';

export const SafetyGame: React.FC = () => {
  const [gameState, setGameState] = useState<'start' | 'playing' | 'end'>('start');
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [currentScenario, setCurrentScenario] = useState<number>(0);

  const scenarios = [
    {
      icon: Flame,
      title: "Fire in the Kitchen",
      description: "A grease fire has started on your stove. What is the safest immediate action?",
      options: [
        { text: "Throw water on it", correct: false, reason: "Water makes grease fires explode!" },
        { text: "Cover with a metal lid", correct: true, reason: "Cutting off oxygen smothers the fire safely." },
        { text: "Fan it with a towel", correct: false, reason: "Fanning it feeds the fire more oxygen." }
      ]
    },
    {
      icon: HeartPulse,
      title: "Unconscious Person",
      description: "You find someone unresponsive on the ground. They are not breathing. What first?",
      options: [
        { text: "Call 999 immediately", correct: true, reason: "Professional help is the priority." },
        { text: "Wait for them to wake up", correct: false, reason: "They need immediate medical intervention." },
        { text: "Try to feed them water", correct: false, reason: "Choking hazard if they are unconscious." }
      ]
    },
    {
      icon: Droplets,
      title: "Flash Flood",
      description: "Flash flood warnings are issued in your area. Where should you go?",
      options: [
        { text: "The basement", correct: false, reason: "Basements are death traps in floods." },
        { text: "The highest ground/floor", correct: true, reason: "Stay above the water line." },
        { text: "Under a big tree", correct: false, reason: "Trees can be uprooted or hit by lightning." }
      ]
    }
  ];

  useEffect(() => {
    let timer: any;
    if (gameState === 'playing' && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (timeLeft === 0) {
      setGameState('end');
    }
    return () => clearInterval(timer);
  }, [gameState, timeLeft]);

  const handleAnswer = (correct: boolean) => {
    if (correct) {
      setScore(prev => prev + 100);
    }
    if (currentScenario < scenarios.length - 1) {
      setCurrentScenario(prev => prev + 1);
    } else {
      setGameState('end');
    }
  };

  const resetGame = () => {
    setScore(0);
    setTimeLeft(30);
    setCurrentScenario(0);
    setGameState('playing');
  };

  if (gameState === 'start') {
    return (
      <div className="bg-white rounded-3xl shadow-xl p-12 text-center border border-gray-100 max-w-2xl mx-auto">
        <div className="bg-red-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8">
          <Shield className="w-12 h-12 text-red-600" />
        </div>
        <h2 className="text-3xl font-bold mb-4">Emergency Drill Challenge</h2>
        <p className="text-gray-600 mb-8 leading-relaxed">
          Test your reaction speed and safety knowledge in 60 seconds. Learn the skills that save lives in real situations.
        </p>
        <button 
          onClick={() => setGameState('playing')}
          className="bg-gray-900 text-white px-8 py-4 rounded-2xl font-bold hover:bg-gray-800 transition shadow-lg"
        >
          START DRILL
        </button>
      </div>
    );
  }

  if (gameState === 'end') {
    return (
      <div className="bg-white rounded-3xl shadow-xl p-12 text-center border border-gray-100 max-w-2xl mx-auto">
        <Award className="w-20 h-20 text-yellow-500 mx-auto mb-6" />
        <h2 className="text-3xl font-bold mb-2">Drill Complete!</h2>
        <div className="text-5xl font-black text-red-600 mb-4">{score} pts</div>
        <p className="text-gray-600 mb-8 italic">
          {score === 300 ? "Excellent! You are an Emergency Response Pro." : "Good effort. Practice more to be ready for real emergencies."}
        </p>
        <button 
          onClick={resetGame}
          className="inline-flex items-center bg-gray-900 text-white px-8 py-4 rounded-2xl font-bold hover:bg-gray-800 transition"
        >
          <RotateCcw className="w-5 h-5 mr-2" /> REPLAY
        </button>
      </div>
    );
  }

  const scenario = scenarios[currentScenario];
  const ScenarioIcon = scenario.icon;

  return (
    <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-10">
        <div className="flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-full font-bold">
          <Timer className="w-4 h-4 text-red-600" /> {timeLeft}s
        </div>
        <div className="text-sm font-semibold text-gray-400">Question {currentScenario + 1} of {scenarios.length}</div>
        <div className="font-bold text-red-600">Score: {score}</div>
      </div>

      <div className="mb-8">
        <div className="bg-red-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
          <ScenarioIcon className="w-8 h-8 text-red-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">{scenario.title}</h3>
        <p className="text-lg text-gray-600">{scenario.description}</p>
      </div>

      <div className="space-y-3">
        {scenario.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => handleAnswer(opt.correct)}
            className="w-full text-left p-6 border-2 border-gray-100 rounded-2xl hover:border-red-500 hover:bg-red-50 transition-all font-semibold text-gray-800"
          >
            {opt.text}
          </button>
        ))}
      </div>
    </div>
  );
};
