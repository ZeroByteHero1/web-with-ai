
import React, { useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell 
} from 'recharts';
import { 
  Search, Filter, CheckCircle, Clock, Truck, ShieldAlert, 
  Map as MapIcon, ChevronRight, MessageSquare
} from 'lucide-react';
import { EmergencyReport, ReportStatus, EmergencyType } from '../types';

interface AdminPanelProps {
  reports: EmergencyReport[];
  onUpdateStatus: (id: string, status: ReportStatus) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ reports, onUpdateStatus }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Stats
  const activeReports = reports.filter(r => r.status !== ReportStatus.RESOLVED).length;
  const resolvedToday = reports.filter(r => r.status === ReportStatus.RESOLVED).length;
  
  const typeData = Object.values(EmergencyType).map(type => ({
    name: type,
    value: reports.filter(r => r.type === type).length
  }));

  const COLORS = ['#ef4444', '#3b82f6', '#f59e0b', '#10b981', '#6366f1'];

  const filteredReports = reports.filter(r => {
    const matchesSearch = r.reporterName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          r.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || r.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Active Alerts', value: activeReports, icon: ShieldAlert, color: 'text-red-600', bg: 'bg-red-50' },
          { label: 'Units Dispatched', value: reports.filter(r => r.status === ReportStatus.DISPATCHED).length, icon: Truck, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Resolved Today', value: resolvedToday, icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Wait Time (Avg)', value: '8.4m', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className={`${stat.bg} ${stat.color} p-2 rounded-lg`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <span className="text-2xl font-bold">{stat.value}</span>
            </div>
            <p className="text-sm font-medium text-gray-500">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Reports Table */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h2 className="text-xl font-bold flex items-center">
              <MessageSquare className="w-5 h-5 mr-2 text-gray-400" />
              Live Emergency Queue
            </h2>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:flex-none">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Search reports..."
                  className="pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-red-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <select 
                className="px-3 py-2 border border-gray-200 rounded-lg text-sm outline-none"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all">All Status</option>
                {Object.values(ReportStatus).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  <th className="px-6 py-4">Reporter</th>
                  <th className="px-6 py-4">Emergency</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredReports.map((report) => (
                  <tr key={report.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-gray-900">{report.reporterName}</div>
                      <div className="text-xs text-gray-500">{report.reporterPhone}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                          report.type === EmergencyType.MEDICAL ? 'bg-red-100 text-red-700' :
                          report.type === EmergencyType.POLICE ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {report.type}
                        </span>
                        <span className="text-xs text-gray-400">{new Date(report.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <div className="text-sm text-gray-600 mt-1 truncate max-w-[200px]">{report.description}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        report.status === ReportStatus.PENDING ? 'bg-amber-100 text-amber-800' :
                        report.status === ReportStatus.DISPATCHED ? 'bg-blue-100 text-blue-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {report.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        {report.status === ReportStatus.PENDING && (
                          <button 
                            onClick={() => onUpdateStatus(report.id, ReportStatus.DISPATCHED)}
                            className="p-1.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100"
                            title="Dispatch Unit"
                          >
                            <Truck className="w-4 h-4" />
                          </button>
                        )}
                        {report.status === ReportStatus.DISPATCHED && (
                          <button 
                            onClick={() => onUpdateStatus(report.id, ReportStatus.RESOLVED)}
                            className="p-1.5 bg-green-50 text-green-600 rounded-lg hover:bg-green-100"
                            title="Resolve Case"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </button>
                        )}
                        <button className="p-1.5 bg-gray-50 text-gray-400 rounded-lg hover:bg-gray-100">
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Analytics */}
        <div className="space-y-8">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <h3 className="font-bold mb-6 flex items-center">
              <BarChart className="w-4 h-4 mr-2 text-red-600" />
              Hotspots Analytics
            </h3>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={typeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {typeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {typeData.map((d, i) => (
                <div key={i} className="flex items-center text-xs text-gray-500">
                  <div className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                  {d.name}: {d.value}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-900 text-white p-6 rounded-2xl shadow-xl">
            <h3 className="font-bold mb-2 flex items-center">
              <MapIcon className="w-4 h-4 mr-2 text-red-400" />
              Zone Distribution
            </h3>
            <p className="text-sm text-gray-400 mb-4">Real-time load balancing across DHAKA, CTG, and SYLHET zones.</p>
            <div className="space-y-4">
              {['Dhaka North', 'Dhaka South', 'Chittagong', 'Sylhet'].map((zone, i) => (
                <div key={zone}>
                  <div className="flex justify-between text-xs mb-1">
                    <span>{zone}</span>
                    <span>{Math.floor(Math.random() * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-1.5">
                    <div className="bg-red-500 h-1.5 rounded-full" style={{ width: `${Math.random() * 80 + 20}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
