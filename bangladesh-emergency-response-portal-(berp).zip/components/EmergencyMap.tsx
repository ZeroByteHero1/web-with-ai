
import React, { useEffect, useRef, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Facility, Coordinates } from '../types';
import { Hospital, Shield, MapPin, Navigation } from 'lucide-react';

// Custom Marker Icons
const hospitalIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const policeIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const userIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

interface EmergencyMapProps {
  userLocation: Coordinates;
  facilities: Facility[];
}

const MapUpdater: React.FC<{ center: Coordinates }> = ({ center }) => {
  const map = useMap();
  useEffect(() => {
    map.setView([center.lat, center.lng], 13);
  }, [center, map]);
  return null;
};

export const EmergencyMap: React.FC<EmergencyMapProps> = ({ userLocation, facilities }) => {
  const [filter, setFilter] = useState<'all' | 'hospital' | 'police'>('all');

  const filteredFacilities = facilities.filter(f => {
    if (filter === 'all') return true;
    if (filter === 'hospital') return f.type === 'Hospital';
    if (filter === 'police') return f.type === 'Police Station';
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <button 
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition ${filter === 'all' ? 'bg-gray-900 text-white' : 'bg-white text-gray-600 border border-gray-200'}`}
        >
          All Nearby
        </button>
        <button 
          onClick={() => setFilter('hospital')}
          className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition ${filter === 'hospital' ? 'bg-red-600 text-white' : 'bg-white text-gray-600 border border-gray-200'}`}
        >
          <Hospital className="w-4 h-4 mr-2" /> Hospitals
        </button>
        <button 
          onClick={() => setFilter('police')}
          className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition ${filter === 'police' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border border-gray-200'}`}
        >
          <Shield className="w-4 h-4 mr-2" /> Police Stations
        </button>
      </div>

      <div className="relative h-[600px] w-full bg-gray-200 rounded-xl overflow-hidden border border-gray-200 shadow-sm">
        <MapContainer center={[userLocation.lat, userLocation.lng]} zoom={13} scrollWheelZoom={false}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapUpdater center={userLocation} />
          
          <Marker position={[userLocation.lat, userLocation.lng]} icon={userIcon}>
            <Popup>
              <div className="font-semibold">Your Location</div>
              <div className="text-xs text-gray-500">Accurate within 10 meters</div>
            </Popup>
          </Marker>

          {filteredFacilities.map(facility => (
            <Marker 
              key={facility.id} 
              position={[facility.location.lat, facility.location.lng]} 
              icon={facility.type === 'Hospital' ? hospitalIcon : policeIcon}
            >
              <Popup>
                <div className="p-1">
                  <h3 className="font-bold text-gray-900">{facility.name}</h3>
                  <p className="text-sm text-gray-500 mb-2">{facility.type}</p>
                  <div className="flex flex-col gap-2">
                    <a 
                      href={`tel:${facility.phone}`}
                      className="flex items-center justify-center w-full bg-gray-900 text-white px-3 py-1.5 rounded text-sm hover:bg-gray-800"
                    >
                      <Navigation className="w-3 h-3 mr-2" /> Call Now
                    </a>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
        
        {/* Legend Overlay */}
        <div className="absolute bottom-4 left-4 z-[1000] bg-white p-3 rounded-lg shadow-lg border border-gray-200 text-xs space-y-2">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
            <span>You</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
            <span>Hospital</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <span>Police Station</span>
          </div>
        </div>
      </div>
    </div>
  );
};
