
import React, { useState } from 'react';
import { Camera, MapPin, Send, AlertTriangle, Loader2, CheckCircle2 } from 'lucide-react';
import { EmergencyType, Coordinates } from '../types';
import { getTriageInstructions } from '../services/geminiService';

interface EmergencyFormProps {
  onSubmit: (data: any) => void;
  userLocation: Coordinates | null;
}

export const EmergencyForm: React.FC<EmergencyFormProps> = ({ onSubmit, userLocation }) => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [triage, setTriage] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    type: EmergencyType.MEDICAL,
    description: '',
    reporterName: '',
    reporterPhone: '',
    address: 'Fetching location...'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Call Gemini for Triage Instructions
    const triageInfo = await getTriageInstructions(formData.type, formData.description);
    setTriage(triageInfo);

    // Simulate API call
    setTimeout(() => {
      onSubmit({
        ...formData,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date(),
        status: 'Pending',
        location: userLocation,
        aiTriage: triageInfo
      });
      setLoading(false);
      setSuccess(true);
    }, 1500);
  };

  if (success) {
    return (
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-lg mx-auto border border-green-100 text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Report Transmitted</h2>
        <p className="text-gray-600 mb-6">Dispatchers have been notified. An emergency unit is being assigned to your location.</p>
        
        {triage && (
          <div className="bg-blue-50 border-l-4 border-blue-500 p-6 text-left mb-6 rounded-r-lg">
            <h3 className="font-bold text-blue-800 mb-2 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" /> AI Safety Triage
            </h3>
            <div className="text-blue-900 prose prose-sm whitespace-pre-wrap">
              {triage}
            </div>
          </div>
        )}

        <button 
          onClick={() => setSuccess(false)}
          className="w-full bg-gray-900 text-white py-3 rounded-xl font-bold hover:bg-gray-800 transition"
        >
          Send Another Report
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 max-w-2xl mx-auto border border-gray-100">
      <div className="flex items-center mb-6">
        <AlertTriangle className="h-8 w-8 text-red-600 mr-3" />
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Emergency Report</h2>
          <p className="text-sm text-gray-500">Fast-track response via digital dispatch</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Emergency Category</label>
            <select
              required
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition"
              value={formData.type}
              onChange={(e) => setFormData({...formData, type: e.target.value as EmergencyType})}
            >
              {Object.values(EmergencyType).map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Your Full Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Rahat Ahmed"
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-red-500 outline-none"
              value={formData.reporterName}
              onChange={(e) => setFormData({...formData, reporterName: e.target.value})}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Contact Phone</label>
            <input
              type="tel"
              required
              placeholder="01xxxxxxxxx"
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-red-500 outline-none"
              value={formData.reporterPhone}
              onChange={(e) => setFormData({...formData, reporterPhone: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Detected Address</label>
            <div className="relative">
              <input
                type="text"
                readOnly
                className="w-full bg-gray-100 border border-gray-200 rounded-lg pl-10 pr-4 py-2.5 text-gray-500 cursor-not-allowed italic"
                value={userLocation ? `${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)} (Automatic)` : "Waiting for GPS..."}
              />
              <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">Situation Details</label>
          <textarea
            required
            rows={4}
            placeholder="Please describe exactly what happened. Be clear and specific (e.g. 'Road accident between bus and car, 3 people injured')."
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-red-500 outline-none transition"
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-4 pt-2">
          <button
            type="button"
            className="flex-1 flex items-center justify-center px-6 py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-600 hover:border-red-400 hover:text-red-500 transition"
          >
            <Camera className="w-5 h-5 mr-2" />
            Attach Photo/Video
          </button>
          <button
            type="submit"
            disabled={loading}
            className="flex-1 flex items-center justify-center bg-red-600 text-white px-6 py-4 rounded-xl font-bold hover:bg-red-700 shadow-lg shadow-red-200 disabled:opacity-70 transition active:scale-[0.98]"
          >
            {loading ? (
              <>
                <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                Transmitting...
              </>
            ) : (
              <>
                <Send className="w-5 h-5 mr-2" />
                SUBMIT EMERGENCY
              </>
            )}
          </button>
        </div>
      </form>
      
      <p className="mt-4 text-xs text-center text-gray-400">
        Submitting false reports is a punishable offense under Bangladesh law. Your device ID and location are logged.
      </p>
    </div>
  );
};
