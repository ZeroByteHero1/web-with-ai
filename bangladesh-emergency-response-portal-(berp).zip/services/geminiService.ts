
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getTriageInstructions = async (type: string, description: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a high-stress emergency dispatcher. A user has reported an emergency in Bangladesh. 
      Type: ${type}. 
      Description: ${description}. 
      Provide 3-4 bullet points of immediate life-saving actions the user should take while waiting for help. 
      Keep it brief and urgent. Respond in English.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "Remain calm and wait for professional help to arrive.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Ensure the scene is safe and wait for the emergency services.";
  }
};
